/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class AMDProgramBinaryZ400 {

	/**
	 * Accepted by the &lt;binaryFormat&gt; parameter of ProgramBinaryOES: 
	 */
	public static final int GL_Z400_BINARY_AMD = 0x8740;

	private AMDProgramBinaryZ400() {}
}
