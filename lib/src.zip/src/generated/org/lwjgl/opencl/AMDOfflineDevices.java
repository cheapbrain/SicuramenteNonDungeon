/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDOfflineDevices {

	public static final int CL_CONTEXT_OFFLINE_DEVICES_AMD = 0x403F;

	private AMDOfflineDevices() {}
}
