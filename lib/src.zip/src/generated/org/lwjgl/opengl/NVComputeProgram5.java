/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVComputeProgram5 {

	/**
	 *  Accepted by the &lt;cap&gt; parameter of Disable, Enable, and IsEnabled,
	 *  by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv, GetFloatv,
	 *  and GetDoublev, and by the &lt;target&gt; parameter of ProgramStringARB,
	 *  BindProgramARB, ProgramEnvParameter4[df][v]ARB,
	 *  ProgramLocalParameter4[df][v]ARB, GetProgramEnvParameter[df]vARB,
	 *  GetProgramLocalParameter[df]vARB, GetProgramivARB and
	 *  GetProgramStringARB:
	 */
	public static final int GL_COMPUTE_PROGRAM_NV = 0x90FB;

	/**
	 *  Accepted by the &lt;target&gt; parameter of ProgramBufferParametersfvNV,
	 *  ProgramBufferParametersIivNV, and ProgramBufferParametersIuivNV,
	 *  BindBufferRangeNV, BindBufferOffsetNV, BindBufferBaseNV, and BindBuffer
	 *  and the &lt;value&gt; parameter of GetIntegerIndexedvEXT:
	 */
	public static final int GL_COMPUTE_PROGRAM_PARAMETER_BUFFER_NV = 0x90FC;

	private NVComputeProgram5() {}
}
