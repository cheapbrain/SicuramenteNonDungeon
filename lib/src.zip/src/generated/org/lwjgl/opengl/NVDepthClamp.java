/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVDepthClamp {

	public static final int GL_DEPTH_CLAMP_NV = 0x864F;

	private NVDepthClamp() {}
}
