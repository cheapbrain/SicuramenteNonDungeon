/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVTexgenReflection {

	public static final int GL_NORMAL_MAP_NV = 0x8511,
		GL_REFLECTION_MAP_NV = 0x8512;

	private NVTexgenReflection() {}
}
