/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBShadow {

	public static final int GL_TEXTURE_COMPARE_MODE_ARB = 0x884C,
		GL_TEXTURE_COMPARE_FUNC_ARB = 0x884D,
		GL_COMPARE_R_TO_TEXTURE_ARB = 0x884E;

	private ARBShadow() {}
}
