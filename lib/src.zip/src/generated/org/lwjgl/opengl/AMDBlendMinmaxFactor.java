/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class AMDBlendMinmaxFactor {

	/**
	 *  Accepted by the &lt;mode&gt; parameter of BlendEquation and BlendEquationi, and by
	 *  the &lt;modeRGB> and &lt;modeAlpha&gt; parameters of BlendEquationSeparate and
	 *  BlendEquationSeparatei:
	 */
	public static final int GL_FACTOR_MIN_AMD = 0x901C,
		GL_FACTOR_MAX_AMD = 0x901D;

	private AMDBlendMinmaxFactor() {}
}
