/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureEnvDot3 {

	public static final int GL_DOT3_RGB_ARB = 0x86AE,
		GL_DOT3_RGBA_ARB = 0x86AF;

	private ARBTextureEnvDot3() {}
}
