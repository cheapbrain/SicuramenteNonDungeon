/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBFragmentShader {

	/**
	 *  Accepted by the &lt;shaderType&gt; argument of CreateShaderObjectARB and
	 *  returned by the &lt;params&gt; parameter of GetObjectParameter{fi}vARB:
	 */
	public static final int GL_FRAGMENT_SHADER_ARB = 0x8B30;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB = 0x8B49,
		GL_MAX_TEXTURE_COORDS_ARB = 0x8871,
		GL_MAX_TEXTURE_IMAGE_UNITS_ARB = 0x8872;

	/**
	 *  Accepted by the &lt;target&gt; parameter of Hint and the &lt;pname&gt; parameter of
	 *  GetBooleanv, GetIntegerv, GetFloatv, and GetDoublev:
	 */
	public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT_ARB = 0x8B8B;

	private ARBFragmentShader() {}
}
